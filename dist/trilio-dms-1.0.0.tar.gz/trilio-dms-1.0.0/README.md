READMEMD = """
# Trilio Dynamic Mount Service

Centralized mount/unmount service for backup targets (S3, NFS) with job-driven bindings and secret management.

## Features

- 🔐 Secure credential management with Barbican
- 📦 Job-driven mount bindings
- 🔄 Automatic reconciliation
- 🚀 Horizontal scalability
- 💾 Persistent mounts across restarts
- 🔧 RESTful and CLI interfaces

## Installation

```bash
pip install trilio-dms
```

## Quick Start

### Server

```bash
trilio-dms \\
  --db-url mysql://user:pass@localhost/trilio_dms \\
  --rabbitmq-url amqp://user:pass@localhost:5672 \\
  --auth-url http://keystone:5000/v3 \\
  --node-id compute-01
```

### Client Usage

```python
from trilio_dms import DMSClient, MountContext

# Create client
client = DMSClient(rabbitmq_url='amqp://localhost:5672')

# Use context manager for automatic cleanup
with MountContext(client, job_id, target_id, token, node_id) as mount:
    # Mount is ready at mount.mount_path
    perform_backup(mount.mount_path)
    # Automatic unmount on exit
```

### CLI

```bash
# Register new target
trilio-dms-cli register

# List targets
trilio-dms-cli list

# Test mount
trilio-dms-cli test-mount <target-id>
```

## Configuration

Set environment variables:

```bash
export DMS_DB_URL="mysql://user:pass@localhost/trilio_dms"
export DMS_RABBITMQ_URL="amqp://user:pass@localhost:5672"
export DMS_AUTH_URL="http://keystone:5000/v3"
export DMS_NODE_ID="$(hostname)"
```

## Architecture

```
┌─────────────┐     RabbitMQ     ┌──────────────┐
│   Client    │ ◄──────────────► │     DMS      │
└─────────────┘                  └──────────────┘
                                        │
                           ┌────────────┼────────────┐
                           │            │            │
                      ┌────▼───┐   ┌───▼────┐  ┌───▼────┐
                      │ MySQL  │   │Barbican│  │Drivers │
                      └────────┘   └────────┘  └────────┘
```

"""

