"""Validation utilities"""

import re
from typing import Optional


def validate_target_id(target_id: str) -> bool:
    """Validate target ID format"""
    uuid_pattern = r'^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$'
    return bool(re.match(uuid_pattern, target_id))


def validate_mount_path(path: str) -> bool:
    """Validate mount path"""
    return path.startswith('/') and not '..' in path


def validate_nfs_share(share: str) -> bool:
    """Validate NFS share format (server:/path)"""
    pattern = r'^[^:]+:.+$'
    return bool(re.match(pattern, share))


def validate_s3_bucket(bucket: str) -> bool:
    """Validate S3 bucket name"""
    pattern = r'^[a-z0-9][a-z0-9\-]*[a-z0-9]$'
    return bool(re.match(pattern, bucket)) and 3 <= len(bucket) <= 63


def validate_endpoint_url(url: str) -> bool:
    """Validate endpoint URL"""
    return url.startswith('http://') or url.startswith('https://')

