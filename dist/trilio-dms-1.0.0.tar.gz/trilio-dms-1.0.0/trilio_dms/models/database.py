"""Database models and session management"""

from datetime import datetime
from sqlalchemy import create_engine, Column, String, Integer, DateTime, Boolean, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, scoped_session, Session
from contextlib import contextmanager
from typing import Generator

from trilio_dms.config import DMSConfig
from trilio_dms.utils.logger import get_logger

LOG = get_logger(__name__)
Base = declarative_base()


class BackupTarget(Base):
    """Backup target metadata"""
    __tablename__ = 'backup_target'
    
    id = Column(String(255), primary_key=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    deleted_at = Column(DateTime, nullable=True)
    deleted = Column(Boolean, default=False)
    name = Column(String(255), nullable=False, unique=True)
    type = Column(String(50), nullable=False)
    mount_path = Column(String(512), nullable=False)
    secret_ref = Column(String(512), nullable=True)
    metadata = Column(Text)
    
    def __repr__(self):
        return f"<BackupTarget(id={self.id}, name={self.name}, type={self.type})>"


class BackupTargetMountLedger(Base):
    """Job-driven mount bindings ledger"""
    __tablename__ = 'backup_target_mount_ledger'
    
    id = Column(String(255), primary_key=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    deleted_at = Column(DateTime, nullable=True)
    deleted = Column(Boolean, default=False)
    version = Column(String(255))
    bt_id = Column(String(255), nullable=False)
    jobs = Column(Text)  # JSON array
    hosts = Column(Text)  # JSON array
    mounted = Column(Boolean, default=False)
    
    def __repr__(self):
        return f"<BackupTargetMountLedger(id={self.id}, bt_id={self.bt_id}, mounted={self.mounted})>"


class Job(Base):
    """Authoritative job table"""
    __tablename__ = 'job'
    
    jobid = Column(Integer, primary_key=True, autoincrement=True)
    parent_jobid = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    deleted_at = Column(DateTime, nullable=True)
    deleted = Column(Boolean, default=False)
    version = Column(String(255))
    progress = Column(Integer, default=0)
    status = Column(String(255))
    completed_at = Column(DateTime, nullable=True)
    action = Column(String(255))
    
    def __repr__(self):
        return f"<Job(jobid={self.jobid}, status={self.status}, action={self.action})>"


class JobDetails(Base):
    """Job details with host and target information"""
    __tablename__ = 'job_details'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    jobid = Column(Integer, nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    deleted_at = Column(DateTime, nullable=True)
    deleted = Column(Boolean, default=False)
    version = Column(String(32))
    data = Column(Text)  # JSON data
    
    def __repr__(self):
        return f"<JobDetails(id={self.id}, jobid={self.jobid})>"


class DatabaseManager:
    """Database connection and session management"""
    
    def __init__(self, config: DMSConfig):
        self.config = config
        self.engine = None
        self.session_factory = None
        self.Session = None
        
    def initialize(self):
        """Initialize database connection"""
        LOG.info(f"Initializing database connection: {self.config.db_url}")
        
        self.engine = create_engine(
            self.config.db_url,
            pool_size=self.config.db_pool_size,
            pool_recycle=self.config.db_pool_recycle,
            echo=False
        )
        
        # Create tables
        Base.metadata.create_all(self.engine)
        
        # Create session factory
        self.session_factory = sessionmaker(bind=self.engine)
        self.Session = scoped_session(self.session_factory)
        
        LOG.info("Database initialized successfully")
    
    def get_session(self) -> Session:
        """Get database session"""
        if not self.Session:
            self.initialize()
        return self.Session()
    
    @contextmanager
    def session_scope(self) -> Generator[Session, None, None]:
        """Provide transactional scope for database operations"""
        session = self.get_session()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()
    
    def close(self):
        """Close database connections"""
        if self.Session:
            self.Session.remove()
        if self.engine:
            self.engine.dispose()


# Global database manager instance
_db_manager = None


def initialize_database(config: DMSConfig):
    """Initialize global database manager"""
    global _db_manager
    _db_manager = DatabaseManager(config)
    _db_manager.initialize()


def get_session() -> Session:
    """Get database session"""
    if not _db_manager:
        raise RuntimeError("Database not initialized. Call initialize_database() first.")
    return _db_manager.get_session()


@contextmanager
def session_scope() -> Generator[Session, None, None]:
    """Provide transactional scope"""
    if not _db_manager:
        raise RuntimeError("Database not initialized. Call initialize_database() first.")
    with _db_manager.session_scope() as session:
        yield session

