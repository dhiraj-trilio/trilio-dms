"""Interactive configuration wizard"""

import json
import uuid
import sys
from keystoneauth1 import session as ks_session
from keystoneauth1.identity import v3

from trilio_dms.config import DMSConfig
from trilio_dms.models import BackupTarget, initialize_database, get_session
from trilio_dms.services.secret_manager import BarbicanSecretManager
from trilio_dms.utils.logger import get_logger
from trilio_dms.utils.validators import (
    validate_nfs_share, validate_s3_bucket, validate_mount_path
)

LOG = get_logger(__name__)


class BackupTargetWizard:
    """Interactive wizard for target registration"""
    
    def __init__(self, config: DMSConfig):
        self.config = config
        initialize_database(config)
        self.secret_manager = BarbicanSecretManager(config.auth_url)
    
    def run(self):
        """Run wizard"""
        print("\n" + "="*60)
        print("Trilio Backup Target Configuration Wizard")
        print("="*60 + "\n")
        
        # Authenticate
        keystone_token = self._get_authentication()
        
        # Get target type
        target_type = self._get_target_type()
        
        if target_type == 's3':
            self._configure_s3_target(keystone_token)
        elif target_type == 'nfs':
            self._configure_nfs_target()
    
    def _get_authentication(self) -> str:
        """Get Keystone authentication"""
        print("Authentication Required")
        print("-" * 40)
        
        username = input("Username: ").strip()
        password = input("Password: ").strip()
        project_name = input("Project Name [admin]: ").strip() or 'admin'
        
        try:
            auth = v3.Password(
                auth_url=self.config.auth_url,
                username=username,
                password=password,
                project_name=project_name,
                user_domain_name='Default',
                project_domain_name='Default'
            )
            sess = ks_session.Session(auth=auth)
            token = sess.get_token()
            
            print("✅ Authentication successful\n")
            return token
            
        except Exception as e:
            print(f"❌ Authentication failed: {e}")
            sys.exit(1)
    
    def _get_target_type(self) -> str:
        """Get target type"""
        print("Select Backup Target Type")
        print("-" * 40)
        print("1. S3 Object Storage")
        print("2. NFS Share")
        
        choice = input("\nEnter choice (1-2): ").strip()
        
        if choice == '1':
            return 's3'
        elif choice == '2':
            return 'nfs'
        else:
            print("Invalid choice")
            return self._get_target_type()
    
    def _configure_s3_target(self, keystone_token: str):
        """Configure S3 target"""
        print("\n" + "="*60)
        print("S3 Target Configuration")
        print("="*60 + "\n")
        
        name = input("Target Name: ").strip()
        bucket = input("S3 Bucket Name: ").strip()
        
        if not validate_s3_bucket(bucket):
            print("❌ Invalid bucket name")
            return
        
        endpoint_url = input("S3 Endpoint URL: ").strip()
        mount_path = input(f"Mount Path [{self.config.mount_base_path}/{name}]: ").strip()
        mount_path = mount_path or f"{self.config.mount_base_path}/{name}"
        
        if not validate_mount_path(mount_path):
            print("❌ Invalid mount path")
            return
        
        print("\nS3 Credentials")
        print("-" * 40)
        access_key = input("Access Key: ").strip()
        secret_key = input("Secret Key: ").strip()
        
        # Store in Barbican
        print("\n🔐 Storing credentials in Barbican...")
        try:
            secret_ref = self.secret_manager.store_credentials(
                name=f"s3_creds_{name}_{uuid.uuid4().hex[:8]}",
                access_key=access_key,
                secret_key=secret_key,
                endpoint_url=endpoint_url,
                keystone_token=keystone_token
            )
            print(f"✅ Credentials stored: {secret_ref}")
        except Exception as e:
            print(f"❌ Failed to store credentials: {e}")
            return
        
        # Save target
        metadata = {
            's3_bucket': bucket,
            's3_endpoint_url': endpoint_url
        }
        
        session = get_session()
        try:
            target = BackupTarget(
                id=str(uuid.uuid4()),
                name=name,
                type='s3',
                mount_path=mount_path,
                secret_ref=secret_ref,
                metadata=json.dumps(metadata)
            )
            
            session.add(target)
            session.commit()
            
            print(f"\n✅ S3 target '{name}' registered successfully!")
            print(f"   Target ID: {target.id}")
            print(f"   Mount Path: {mount_path}")
            print(f"   Bucket: {bucket}")
            
        except Exception as e:
            print(f"❌ Failed to register target: {e}")
            session.rollback()
        finally:
            session.close()
    
    def _configure_nfs_target(self):
        """Configure NFS target"""
        print("\n" + "="*60)
        print("NFS Target Configuration")
        print("="*60 + "\n")
        
        name = input("Target Name: ").strip()
        nfs_share = input("NFS Share (server:/export/path): ").strip()
        
        if not validate_nfs_share(nfs_share):
            print("❌ Invalid NFS share format")
            return
        
        mount_path = input(f"Mount Path [{self.config.mount_base_path}/{name}]: ").strip()
        mount_path = mount_path or f"{self.config.mount_base_path}/{name}"
        
        if not validate_mount_path(mount_path):
            print("❌ Invalid mount path")
            return
        
        mount_options = input("Mount Options [defaults]: ").strip() or 'defaults'
        
        # Save target
        metadata = {
            'nfs_share': nfs_share,
            'nfs_options': mount_options
        }
        
        session = get_session()
        try:
            target = BackupTarget(
                id=str(uuid.uuid4()),
                name=name,
                type='nfs',
                mount_path=mount_path,
                secret_ref=None,
                metadata=json.dumps(metadata)
            )
            
            session.add(target)
            session.commit()
            
            print(f"\n✅ NFS target '{name}' registered successfully!")
            print(f"   Target ID: {target.id}")
            print(f"   Mount Path: {mount_path}")
            print(f"   Share: {nfs_share}")
            
        except Exception as e:
            print(f"❌ Failed to register target: {e}")
            session.rollback()
        finally:
            session.close()

