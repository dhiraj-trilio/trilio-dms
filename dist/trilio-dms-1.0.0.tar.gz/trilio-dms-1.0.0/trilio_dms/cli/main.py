"""Main CLI entry point"""

import click
import socket
from trilio_dms.cli import commands
from trilio_dms.config import DMSConfig


@click.group()
@click.pass_context
def cli(ctx):
    """Trilio Dynamic Mount Service CLI"""
    ctx.ensure_object(dict)
    ctx.obj['config'] = DMSConfig()


@cli.command()
@click.pass_context
def register(ctx):
    """Register new backup target"""
    from trilio_dms.cli.wizard import BackupTargetWizard
    config = ctx.obj['config']
    wizard = BackupTargetWizard(config)
    wizard.run()


@cli.command()
@click.pass_context
def list(ctx):
    """List all registered targets"""
    commands.list_targets(ctx.obj['config'])


@cli.command()
@click.argument('target_id')
@click.pass_context
def delete(ctx, target_id):
    """Delete a target"""
    commands.delete_target(ctx.obj['config'], target_id)


@cli.command()
@click.argument('target_id')
@click.option('--job-id', default=99999, help='Test job ID')
@click.option('--node-id', default=socket.gethostname(), help='Node ID')
@click.pass_context
def test_mount(ctx, target_id, job_id, node_id):
    """Test mount operation"""
    commands.test_mount(ctx.obj['config'], target_id, job_id, node_id)


@cli.command()
@click.option('--output', default='/etc/systemd/system/trilio-dms.service',
              help='Output file path')
@click.pass_context
def generate_systemd(ctx, output):
    """Generate systemd service file"""
    commands.generate_systemd_service(ctx.obj['config'], output)


@cli.command()
@click.option('--target-id', required=True, help='Target ID')
@click.pass_context
def show(ctx, target_id):
    """Show target details"""
    commands.show_target(ctx.obj['config'], target_id)


@cli.command()
@click.pass_context
def status(ctx):
    """Show DMS service status"""
    commands.show_status(ctx.obj['config'])


def main():
    """Main entry point"""
    cli(obj={})


if __name__ == '__main__':
    main()

