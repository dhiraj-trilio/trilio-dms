"""CLI command implementations"""

import json
import socket
from datetime import datetime
from keystoneauth1 import session as ks_session
from keystoneauth1.identity import v3

from trilio_dms.config import DMSConfig
from trilio_dms.models import BackupTarget, get_session, initialize_database
from trilio_dms.client import DMSClient
from trilio_dms.utils.logger import get_logger

LOG = get_logger(__name__)


def list_targets(config: DMSConfig):
    """List all registered targets"""
    initialize_database(config)
    session = get_session()
    
    try:
        targets = session.query(BackupTarget).filter_by(deleted=False).all()
        
        print("\n" + "="*100)
        print("Registered Backup Targets")
        print("="*100)
        print(f"{'Name':<25} {'Type':<10} {'Mount Path':<35} {'ID':<30}")
        print("-"*100)
        
        for target in targets:
            print(f"{target.name:<25} {target.type:<10} {target.mount_path:<35} {target.id:<30}")
        
        print(f"\nTotal: {len(targets)} targets")
        
    finally:
        session.close()


def delete_target(config: DMSConfig, target_id: str):
    """Delete a target"""
    initialize_database(config)
    session = get_session()
    
    try:
        target = session.query(BackupTarget).filter_by(id=target_id).first()
        
        if not target:
            print(f"❌ Target {target_id} not found")
            return
        
        confirm = input(f"Delete target '{target.name}'? (yes/no): ").strip().lower()
        if confirm == 'yes':
            target.deleted = True
            target.deleted_at = datetime.utcnow()
            session.commit()
            print(f"✅ Target '{target.name}' deleted")
        else:
            print("Cancelled")
            
    finally:
        session.close()


def test_mount(config: DMSConfig, target_id: str, job_id: int, node_id: str):
    """Test mount operation"""
    # Get authentication
    print("\nAuthentication Required")
    print("-" * 40)
    username = input("Username: ").strip()
    password = input("Password: ").strip()
    project_name = input("Project [admin]: ").strip() or 'admin'
    
    try:
        auth = v3.Password(
            auth_url=config.auth_url,
            username=username,
            password=password,
            project_name=project_name,
            user_domain_name='Default',
            project_domain_name='Default'
        )
        sess = ks_session.Session(auth=auth)
        token = sess.get_token()
        
        print("✅ Authentication successful\n")
        
        # Test mount
        with DMSClient(config) as client:
            print(f"Testing mount for target {target_id}...")
            response = client.mount(job_id, target_id, token, node_id)
            
            print(f"\nMount Response:")
            print(json.dumps(response, indent=2))
            
            if response.get('success'):
                input("\n⏸  Press Enter to unmount...")
                response = client.unmount(job_id, target_id, node_id)
                print(f"\nUnmount Response:")
                print(json.dumps(response, indent=2))
        
    except Exception as e:
        print(f"❌ Test failed: {e}")


def show_target(config: DMSConfig, target_id: str):
    """Show target details"""
    initialize_database(config)
    session = get_session()
    
    try:
        target = session.query(BackupTarget).filter_by(id=target_id).first()
        
        if not target:
            print(f"❌ Target {target_id} not found")
            return
        
        metadata = json.loads(target.metadata or '{}')
        
        print("\n" + "="*60)
        print(f"Target: {target.name}")
        print("="*60)
        print(f"ID:           {target.id}")
        print(f"Type:         {target.type}")
        print(f"Mount Path:   {target.mount_path}")
        print(f"Created:      {target.created_at}")
        print(f"Updated:      {target.updated_at}")
        
        if target.secret_ref:
            print(f"Secret Ref:   {target.secret_ref}")
        
        print("\nMetadata:")
        print(json.dumps(metadata, indent=2))
        
    finally:
        session.close()


def show_status(config: DMSConfig):
    """Show DMS service status"""
    import subprocess
    
    print("\nDMS Service Status")
    print("="*60)
    
    try:
        result = subprocess.run(
            ['systemctl', 'status', 'trilio-dms'],
            capture_output=True,
            text=True
        )
        print(result.stdout)
    except Exception as e:
        print(f"❌ Could not get service status: {e}")


def generate_systemd_service(config: DMSConfig, output_file: str):
    """Generate systemd service file"""
    template = f"""[Unit]
Description=Trilio Dynamic Mount Service
After=network.target rabbitmq-server.service mysql.service
Wants=rabbitmq-server.service mysql.service

[Service]
Type=simple
User=root
Group=root
WorkingDirectory=/opt/trilio/dms

Environment="DMS_DB_URL={config.db_url}"
Environment="DMS_RABBITMQ_URL={config.rabbitmq_url}"
Environment="DMS_AUTH_URL={config.auth_url}"
Environment="DMS_NODE_ID={config.node_id}"

ExecStart=/usr/bin/python3 -m trilio_dms.server.dms_server

# KillMode=process ensures child FUSE processes survive DMS restart
KillMode=process
Restart=always
RestartSec=10

# Resource limits
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
"""
    
    try:
        with open(output_file, 'w') as f:
            f.write(template)
        
        print(f"✅ Service file created: {output_file}")
        print("\nNext steps:")
        print("  1. systemctl daemon-reload")
        print("  2. systemctl enable trilio-dms")
        print("  3. systemctl start trilio-dms")
        print("  4. systemctl status trilio-dms")
        
    except Exception as e:
        print(f"❌ Failed to create service file: {e}")

