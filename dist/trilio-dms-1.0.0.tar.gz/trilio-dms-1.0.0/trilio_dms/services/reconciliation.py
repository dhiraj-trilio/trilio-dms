"""Reconciliation service for startup and periodic sync"""

import json
from typing import List

from trilio_dms.config import DMSConfig
from trilio_dms.models import BackupTarget, BackupTargetMountLedger, Job, session_scope
from trilio_dms.drivers import NFSDriver, S3FuseDriver
from trilio_dms.utils.logger import get_logger

LOG = get_logger(__name__)


class ReconciliationService:
    """Service for reconciling mount state"""
    
    def __init__(self, config: DMSConfig, mount_service):
        self.config = config
        self.mount_service = mount_service
        self.nfs_driver = NFSDriver()
        self.s3_driver = S3FuseDriver(config.s3_pidfile_dir)
    
    def reconcile_on_startup(self):
        """Reconcile all mounts on startup"""
        LOG.info("Starting reconciliation on startup...")
        
        # Reconcile S3 mounts first
        self.s3_driver.reconcile_on_startup()
        
        with session_scope() as session:
            ledgers = session.query(BackupTargetMountLedger).all()
            
            for ledger in ledgers:
                hosts = json.loads(ledger.hosts or '[]')
                if self.config.node_id not in hosts:
                    continue
                
                try:
                    self._reconcile_target(session, ledger)
                except Exception as e:
                    LOG.error(f"Failed to reconcile target {ledger.bt_id}: {e}")
        
        LOG.info("Reconciliation complete")
    
    def _reconcile_target(self, session, ledger: BackupTargetMountLedger):
        """Reconcile a single target"""
        target = session.query(BackupTarget).filter_by(
            id=ledger.bt_id, deleted=False
        ).first()
        
        if not target:
            LOG.warning(f"Target {ledger.bt_id} not found, skipping")
            return
        
        # Compute desired state
        active_count = self._compute_active_count(session, ledger.bt_id)
        
        # Check actual state
        if target.type == 'nfs':
            is_mounted = self.nfs_driver.is_mounted(target.mount_path)
        else:
            is_mounted = self.s3_driver.is_mounted(target.mount_path)
        
        LOG.info(f"Reconciling {target.id}: active={active_count}, mounted={is_mounted}")
        
        # Converge to desired state
        if active_count > 0 and not is_mounted:
            LOG.info(f"Remounting {target.id} (jobs active but not mounted)")
            # Note: Can't mount S3 without token during reconciliation
            # This is a known limitation - jobs will retry mount requests
        elif active_count == 0 and is_mounted:
            LOG.info(f"Unmounting {target.id} (no active jobs)")
            self.mount_service._perform_unmount(target)
            ledger.mounted = False
        elif is_mounted:
            LOG.info(f"Adopting existing mount for {target.id}")
            ledger.mounted = True
    
    def _compute_active_count(self, session, target_id: str) -> int:
        """Compute active job count"""
        ledger = session.query(BackupTargetMountLedger).filter_by(
            bt_id=target_id
        ).first()
        
        if not ledger:
            return 0
        
        jobs = json.loads(ledger.jobs or '[]')
        return session.query(Job).filter(
            Job.jobid.in_(jobs),
            Job.status.in_(['STARTING', 'RUNNING']),
            Job.deleted == False
        ).count()
