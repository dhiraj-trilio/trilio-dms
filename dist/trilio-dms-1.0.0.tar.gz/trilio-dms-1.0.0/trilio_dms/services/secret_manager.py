"""Secret management service for Barbican integration"""

import json
from typing import Dict, Optional

from keystoneauth1 import session as ks_session
from keystoneauth1.identity import v3
from barbicanclient.v1 import client as barbican_client

from trilio_dms.utils.logger import get_logger
from trilio_dms.utils.exceptions import AuthenticationException

LOG = get_logger(__name__)


class BarbicanSecretManager:
    """Barbican secret manager for S3 credentials"""
    
    def __init__(self, auth_url: str):
        self.auth_url = auth_url
    
    def _get_client(self, keystone_token: str = None, 
                   username: str = None, password: str = None,
                   project_name: str = None) -> barbican_client.Client:
        """Get authenticated Barbican client"""
        try:
            if keystone_token:
                auth = v3.Token(auth_url=self.auth_url, token=keystone_token)
            else:
                auth = v3.Password(
                    auth_url=self.auth_url,
                    username=username,
                    password=password,
                    project_name=project_name,
                    user_domain_name='Default',
                    project_domain_name='Default'
                )
            
            sess = ks_session.Session(auth=auth)
            return barbican_client.Client(session=sess)
            
        except Exception as e:
            raise AuthenticationException(f"Failed to authenticate with Barbican: {e}")
    
    def store_credentials(self, name: str, access_key: str, secret_key: str,
                         endpoint_url: str, keystone_token: str = None,
                         **auth_kwargs) -> str:
        """Store S3 credentials in Barbican"""
        try:
            barbican = self._get_client(keystone_token=keystone_token, **auth_kwargs)
            
            payload = json.dumps({
                'access_key': access_key,
                'secret_key': secret_key,
                'endpoint_url': endpoint_url
            })
            
            secret = barbican.secrets.create(
                name=name,
                payload=payload,
                payload_content_type='application/json'
            )
            
            secret_ref = secret.store()
            LOG.info(f"Stored credentials in Barbican: {secret_ref}")
            return secret_ref
            
        except Exception as e:
            LOG.error(f"Failed to store credentials: {e}")
            raise
    
    def retrieve_credentials(self, secret_ref: str, 
                           keystone_token: str) -> Dict[str, str]:
        """Retrieve S3 credentials from Barbican"""
        try:
            barbican = self._get_client(keystone_token=keystone_token)
            secret = barbican.secrets.get(secret_ref)
            credentials = json.loads(secret.payload)
            
            LOG.info(f"Retrieved credentials from Barbican")
            return credentials
            
        except Exception as e:
            LOG.error(f"Failed to retrieve credentials: {e}")
            raise
    
    def delete_credentials(self, secret_ref: str, keystone_token: str) -> bool:
        """Delete credentials from Barbican"""
        try:
            barbican = self._get_client(keystone_token=keystone_token)
            secret = barbican.secrets.get(secret_ref)
            secret.delete()
            
            LOG.info(f"Deleted credentials from Barbican")
            return True
            
        except Exception as e:
            LOG.error(f"Failed to delete credentials: {e}")
            return False

