"""Core mount service implementation"""

import json
from typing import Dict, Optional

from trilio_dms.config import DMSConfig
from trilio_dms.models import BackupTarget, BackupTargetMountLedger, Job, session_scope
from trilio_dms.drivers import NFSDriver, S3FuseDriver
from trilio_dms.services.secret_manager import BarbicanSecretManager
from trilio_dms.utils.logger import get_logger
from trilio_dms.utils.exceptions import (
    MountException, UnmountException, TargetNotFoundException
)

LOG = get_logger(__name__)


class MountService:
    """Core mount/unmount service"""
    
    def __init__(self, config: DMSConfig):
        self.config = config
        self.nfs_driver = NFSDriver()
        self.s3_driver = S3FuseDriver(config.s3_pidfile_dir)
        self.secret_manager = BarbicanSecretManager(config.auth_url)
    
    def mount(self, job_id: int, target_id: str, keystone_token: str) -> Dict:
        """Handle mount request"""
        with session_scope() as session:
            try:
                # Load target
                target = session.query(BackupTarget).filter_by(
                    id=target_id, deleted=False
                ).first()
                
                if not target:
                    raise TargetNotFoundException(f"Target {target_id} not found")
                
                # Update ledger
                ledger = session.query(BackupTargetMountLedger).filter_by(
                    bt_id=target_id
                ).first()
                
                if not ledger:
                    ledger = BackupTargetMountLedger(
                        id=f"{target_id}_{self.config.node_id}",
                        bt_id=target_id,
                        jobs=json.dumps([job_id]),
                        hosts=json.dumps([self.config.node_id]),
                        mounted=False
                    )
                    session.add(ledger)
                else:
                    jobs = json.loads(ledger.jobs or '[]')
                    if job_id not in jobs:
                        jobs.append(job_id)
                        ledger.jobs = json.dumps(jobs)
                
                session.commit()
                
                # Check if mount needed
                active_count = self._compute_active_count(session, target_id)
                
                if active_count == 1 and not self._is_mounted(target):
                    # Perform mount
                    self._perform_mount(target, keystone_token)
                    ledger.mounted = True
                    session.commit()
                
                return {
                    'success': True,
                    'message': f'Mount ready for job {job_id}',
                    'mount_path': target.mount_path
                }
                
            except Exception as e:
                LOG.error(f"Mount failed: {e}")
                return {
                    'success': False,
                    'message': str(e)
                }
    
    def unmount(self, job_id: int, target_id: str) -> Dict:
        """Handle unmount request"""
        with session_scope() as session:
            try:
                # Update ledger
                ledger = session.query(BackupTargetMountLedger).filter_by(
                    bt_id=target_id
                ).first()
                
                if ledger:
                    jobs = json.loads(ledger.jobs or '[]')
                    if job_id in jobs:
                        jobs.remove(job_id)
                        ledger.jobs = json.dumps(jobs)
                
                session.commit()
                
                # Check if unmount needed
                active_count = self._compute_active_count(session, target_id)
                
                if active_count == 0 and ledger and ledger.mounted:
                    # Perform unmount
                    target = session.query(BackupTarget).filter_by(id=target_id).first()
                    if target:
                        self._perform_unmount(target)
                        ledger.mounted = False
                        session.commit()
                
                return {
                    'success': True,
                    'message': f'Unmount processed for job {job_id}'
                }
                
            except Exception as e:
                LOG.error(f"Unmount failed: {e}")
                return {
                    'success': False,
                    'message': str(e)
                }
    
    def _compute_active_count(self, session, target_id: str) -> int:
        """Compute active job count for target"""
        ledger = session.query(BackupTargetMountLedger).filter_by(
            bt_id=target_id
        ).first()
        
        if not ledger:
            return 0
        
        jobs = json.loads(ledger.jobs or '[]')
        
        # Count jobs in STARTING or RUNNING state
        active_jobs = session.query(Job).filter(
            Job.jobid.in_(jobs),
            Job.status.in_(['STARTING', 'RUNNING']),
            Job.deleted == False
        ).count()
        
        return active_jobs
    
    def _is_mounted(self, target: BackupTarget) -> bool:
        """Check if target is mounted"""
        if target.type == 'nfs':
            return self.nfs_driver.is_mounted(target.mount_path)
        elif target.type == 's3':
            return self.s3_driver.is_mounted(target.mount_path)
        return False
    
    def _perform_mount(self, target: BackupTarget, keystone_token: str):
        """Perform actual mount operation"""
        metadata = json.loads(target.metadata or '{}')
        
        if target.type == 'nfs':
            success = self.nfs_driver.mount(
                target_id=target.id,
                mount_path=target.mount_path,
                share=metadata.get('nfs_share'),
                options=metadata.get('nfs_options')
            )
        elif target.type == 's3':
            credentials = self.secret_manager.retrieve_credentials(
                target.secret_ref, keystone_token
            )
            success = self.s3_driver.mount(
                target_id=target.id,
                mount_path=target.mount_path,
                bucket=metadata.get('s3_bucket'),
                credentials=credentials
            )
        else:
            raise MountException(f"Unknown target type: {target.type}")
        
        if not success:
            raise MountException(f"Failed to mount {target.id}")
    
    def _perform_unmount(self, target: BackupTarget):
        """Perform actual unmount operation"""
        if target.type == 'nfs':
            success = self.nfs_driver.unmount(target.id, target.mount_path)
        elif target.type == 's3':
            success = self.s3_driver.unmount(target.id, target.mount_path)
        else:
            raise UnmountException(f"Unknown target type: {target.type}")
        
        if not success:
            raise UnmountException(f"Failed to unmount {target.id}")
