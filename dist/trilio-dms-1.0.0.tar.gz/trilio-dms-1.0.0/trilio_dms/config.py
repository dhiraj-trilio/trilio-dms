"""Configuration management for Trilio DMS"""

import os
from typing import Optional
from dataclasses import dataclass


@dataclass
class DMSConfig:
    """DMS Configuration"""
    
    # Database
    db_url: str = os.getenv('DMS_DB_URL', 'mysql://root@localhost/trilio_dms')
    db_pool_size: int = int(os.getenv('DMS_DB_POOL_SIZE', '10'))
    db_pool_recycle: int = int(os.getenv('DMS_DB_POOL_RECYCLE', '3600'))
    
    # RabbitMQ
    rabbitmq_url: str = os.getenv('DMS_RABBITMQ_URL', 'amqp://guest:guest@localhost:5672')
    rabbitmq_queue: str = os.getenv('DMS_RABBITMQ_QUEUE', 'trilio_dms_ops')
    rabbitmq_prefetch: int = int(os.getenv('DMS_RABBITMQ_PREFETCH', '1'))
    rabbitmq_heartbeat: int = int(os.getenv('DMS_RABBITMQ_HEARTBEAT', '60'))
    
    # Authentication
    auth_url: str = os.getenv('DMS_AUTH_URL', 'http://localhost:5000/v3')
    
    # Service
    node_id: str = os.getenv('DMS_NODE_ID', 'localhost')
    log_level: str = os.getenv('DMS_LOG_LEVEL', 'INFO')
    
    # Mounts
    mount_base_path: str = os.getenv('DMS_MOUNT_BASE', '/mnt/trilio')
    s3_pidfile_dir: str = os.getenv('DMS_S3_PIDFILE_DIR', '/run/dms/s3')
    mount_timeout: int = int(os.getenv('DMS_MOUNT_TIMEOUT', '60'))
    
    # Operations
    operation_timeout: int = int(os.getenv('DMS_OPERATION_TIMEOUT', '300'))
    reconcile_interval: int = int(os.getenv('DMS_RECONCILE_INTERVAL', '300'))
    
    # Security
    verify_ssl: bool = os.getenv('DMS_VERIFY_SSL', 'true').lower() == 'true'
    
    @classmethod
    def from_file(cls, config_file: str) -> 'DMSConfig':
        """Load configuration from file"""
        import json
        with open(config_file, 'r') as f:
            config_data = json.load(f)
        return cls(**config_data)

