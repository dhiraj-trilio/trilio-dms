"""Messaging package"""

from trilio_dms.messaging.rabbitmq import RabbitMQClient, RabbitMQServer

__all__ = ['RabbitMQClient', 'RabbitMQServer']

