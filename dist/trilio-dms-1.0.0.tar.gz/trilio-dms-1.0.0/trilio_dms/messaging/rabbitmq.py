"""RabbitMQ messaging implementation"""

import json
import uuid
import time
from typing import Dict, Callable, Optional
import pika

from trilio_dms.config import DMSConfig
from trilio_dms.utils.logger import get_logger
from trilio_dms.utils.exceptions import MessagingException

LOG = get_logger(__name__)


class RabbitMQClient:
    """RabbitMQ client for sending requests"""
    
    def __init__(self, config: DMSConfig):
        self.config = config
        self.connection = None
        self.channel = None
        self.callback_queue = None
        self.response = None
        self.corr_id = None
    
    def connect(self):
        """Connect to RabbitMQ"""
        try:
            params = pika.URLParameters(self.config.rabbitmq_url)
            params.heartbeat = self.config.rabbitmq_heartbeat
            
            self.connection = pika.BlockingConnection(params)
            self.channel = self.connection.channel()
            
            # Declare callback queue
            result = self.channel.queue_declare(queue='', exclusive=True)
            self.callback_queue = result.method.queue
            
            self.channel.basic_consume(
                queue=self.callback_queue,
                on_message_callback=self._on_response,
                auto_ack=True
            )
            
            LOG.info("Connected to RabbitMQ")
            
        except Exception as e:
            raise MessagingException(f"Failed to connect to RabbitMQ: {e}")
    
    def _on_response(self, ch, method, props, body):
        """Handle RPC response"""
        if self.corr_id == props.correlation_id:
            self.response = json.loads(body)
    
    def call(self, request: Dict, timeout: Optional[int] = None) -> Dict:
        """Make RPC call"""
        if not self.connection or self.connection.is_closed:
            self.connect()
        
        timeout = timeout or self.config.operation_timeout
        self.response = None
        self.corr_id = str(uuid.uuid4())
        
        self.channel.basic_publish(
            exchange='',
            routing_key=self.config.rabbitmq_queue,
            properties=pika.BasicProperties(
                reply_to=self.callback_queue,
                correlation_id=self.corr_id,
                delivery_mode=2,
            ),
            body=json.dumps(request)
        )
        
        # Wait for response
        start_time = time.time()
        while self.response is None:
            self.connection.process_data_events(time_limit=1)
            if time.time() - start_time > timeout:
                raise TimeoutError(f"Request timed out after {timeout}s")
        
        return self.response
    
    def close(self):
        """Close connection"""
        if self.connection and not self.connection.is_closed:
            self.connection.close()


class RabbitMQServer:
    """RabbitMQ server for handling requests"""
    
    def __init__(self, config: DMSConfig, handler: Callable):
        self.config = config
        self.handler = handler
        self.connection = None
        self.channel = None
        self.consuming = False
    
    def connect(self):
        """Connect to RabbitMQ"""
        try:
            params = pika.URLParameters(self.config.rabbitmq_url)
            params.heartbeat = self.config.rabbitmq_heartbeat
            
            self.connection = pika.BlockingConnection(params)
            self.channel = self.connection.channel()
            
            # Declare queue
            self.channel.queue_declare(
                queue=self.config.rabbitmq_queue,
                durable=True
            )
            
            LOG.info("Connected to RabbitMQ")
            
        except Exception as e:
            raise MessagingException(f"Failed to connect to RabbitMQ: {e}")
    
    def start_consuming(self):
        """Start consuming messages"""
        if not self.connection:
            self.connect()
        
        self.consuming = True
        self.channel.basic_qos(prefetch_count=self.config.rabbitmq_prefetch)
        self.channel.basic_consume(
            queue=self.config.rabbitmq_queue,
            on_message_callback=self._on_request
        )
        
        LOG.info(f"Started consuming from {self.config.rabbitmq_queue}")
        
        try:
            while self.consuming:
                self.connection.process_data_events(time_limit=1)
        except KeyboardInterrupt:
            LOG.info("Interrupted, stopping...")
        finally:
            self.stop()
    
    def _on_request(self, ch, method, props, body):
        """Handle incoming request"""
        try:
            request = json.loads(body)
            LOG.info(f"Received request: {request.get('operation')}")
            
            # Call handler
            response = self.handler(request)
            
            # Send response
            if props.reply_to:
                ch.basic_publish(
                    exchange='',
                    routing_key=props.reply_to,
                    properties=pika.BasicProperties(
                        correlation_id=props.correlation_id
                    ),
                    body=json.dumps(response)
                )
            
            # Acknowledge
            ch.basic_ack(delivery_tag=method.delivery_tag)
            
        except Exception as e:
            LOG.error(f"Error handling request: {e}")
            ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False)
    
    def stop(self):
        """Stop consuming"""
        self.consuming = False
        if self.connection and not self.connection.is_closed:
            self.connection.close()

