"""DMS client library"""

from datetime import datetime
from typing import Dict

from trilio_dms.config import DMSConfig
from trilio_dms.messaging.rabbitmq import RabbitMQClient
from trilio_dms.utils.logger import get_logger

LOG = get_logger(__name__)


class DMSClient:
    """High-level DMS client"""
    
    def __init__(self, config: DMSConfig = None, rabbitmq_url: str = None):
        if config:
            self.config = config
        else:
            self.config = DMSConfig()
            if rabbitmq_url:
                self.config.rabbitmq_url = rabbitmq_url
        
        self.mq_client = RabbitMQClient(self.config)
    
    def mount(self, job_id: int, target_id: str, keystone_token: str,
              node_id: str = None) -> Dict:
        """Request mount"""
        node_id = node_id or self.config.node_id
        
        request = {
            'operation': 'mount',
            'job_id': job_id,
            'target_id': target_id,
            'token': keystone_token,
            'node_id': node_id,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        LOG.info(f"Requesting mount for job {job_id}, target {target_id}")
        response = self.mq_client.call(request)
        
        if response.get('success'):
            LOG.info(f"Mount successful: {response.get('mount_path')}")
        else:
            LOG.error(f"Mount failed: {response.get('message')}")
        
        return response
    
    def unmount(self, job_id: int, target_id: str, node_id: str = None) -> Dict:
        """Request unmount"""
        node_id = node_id or self.config.node_id
        
        request = {
            'operation': 'unmount',
            'job_id': job_id,
            'target_id': target_id,
            'node_id': node_id,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        LOG.info(f"Requesting unmount for job {job_id}, target {target_id}")
        response = self.mq_client.call(request)
        
        return response
    
    def close(self):
        """Close client"""
        self.mq_client.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
