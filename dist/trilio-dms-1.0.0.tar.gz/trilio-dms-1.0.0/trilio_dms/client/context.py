"""Context manager for mount operations"""

from trilio_dms.client.dms_client import DMSClient


class MountContext:
    """Context manager for automatic mount/unmount"""
    
    def __init__(self, client: DMSClient, job_id: int, target_id: str,
                 keystone_token: str, node_id: str = None):
        self.client = client
        self.job_id = job_id
        self.target_id = target_id
        self.keystone_token = keystone_token
        self.node_id = node_id
        self.mount_path = None
        self.mounted = False
    
    def __enter__(self):
        response = self.client.mount(
            self.job_id,
            self.target_id,
            self.keystone_token,
            self.node_id
        )
        
        if not response.get('success'):
            raise RuntimeError(f"Mount failed: {response.get('message')}")
        
        self.mount_path = response.get('mount_path')
        self.mounted = True
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.mounted:
            self.client.unmount(self.job_id, self.target_id, self.node_id)
