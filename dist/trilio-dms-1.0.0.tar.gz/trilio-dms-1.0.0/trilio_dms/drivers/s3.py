"""S3 FUSE mount driver implementation"""

import os
import signal
import subprocess
import time
from typing import Dict, Any, Optional
import threading
import psutil

from trilio_dms.drivers.base import BaseMountDriver
from trilio_dms.utils.logger import get_logger
from trilio_dms.utils.exceptions import MountException, UnmountException

LOG = get_logger(__name__)


class S3FuseDriver(BaseMountDriver):
    """S3 FUSE mount driver with subprocess supervision"""
    
    def __init__(self, pidfile_dir: str = '/run/dms/s3'):
        self.pidfile_dir = pidfile_dir
        os.makedirs(pidfile_dir, exist_ok=True)
        self.processes: Dict[str, subprocess.Popen] = {}
        self.process_lock = threading.Lock()
    
    def _get_pidfile(self, target_id: str) -> str:
        """Get pidfile path"""
        return os.path.join(self.pidfile_dir, f"{target_id}.pid")
    
    def _get_passwd_file(self, target_id: str) -> str:
        """Get password file path"""
        return os.path.join(self.pidfile_dir, f"{target_id}.passwd")
    
    def _write_pidfile(self, target_id: str, pid: int):
        """Write PID to file"""
        with open(self._get_pidfile(target_id), 'w') as f:
            f.write(str(pid))
    
    def _read_pidfile(self, target_id: str) -> Optional[int]:
        """Read PID from file"""
        pidfile = self._get_pidfile(target_id)
        try:
            if os.path.exists(pidfile):
                with open(pidfile, 'r') as f:
                    return int(f.read().strip())
        except Exception as e:
            LOG.error(f"Error reading pidfile: {e}")
        return None
    
    def _remove_pidfile(self, target_id: str):
        """Remove pidfile"""
        pidfile = self._get_pidfile(target_id)
        try:
            if os.path.exists(pidfile):
                os.remove(pidfile)
        except Exception as e:
            LOG.error(f"Error removing pidfile: {e}")
    
    def _create_passwd_file(self, target_id: str, credentials: Dict[str, str]) -> str:
        """Create password file for s3fs"""
        passwd_file = self._get_passwd_file(target_id)
        with open(passwd_file, 'w') as f:
            f.write(f"{credentials['access_key']}:{credentials['secret_key']}")
        os.chmod(passwd_file, 0o600)
        return passwd_file
    
    def _remove_passwd_file(self, target_id: str):
        """Remove password file"""
        passwd_file = self._get_passwd_file(target_id)
        try:
            if os.path.exists(passwd_file):
                os.remove(passwd_file)
        except Exception as e:
            LOG.error(f"Error removing passwd file: {e}")
    
    def mount(self, target_id: str, mount_path: str, **kwargs) -> bool:
        """Mount S3 bucket using FUSE"""
        bucket = kwargs.get('bucket')
        credentials = kwargs.get('credentials')
        
        if not bucket:
            raise MountException("S3 bucket not specified")
        if not credentials:
            raise MountException("S3 credentials not provided")
        
        try:
            # Create mount point
            os.makedirs(mount_path, exist_ok=True)
            
            # Create password file
            passwd_file = self._create_passwd_file(target_id, credentials)
            
            # Build s3fs command
            cmd = [
                's3fs',
                bucket,
                mount_path,
                '-f',  # Foreground
                '-o', f'passwd_file={passwd_file}',
                '-o', f"url={credentials.get('endpoint_url', 'https://s3.amazonaws.com')}",
                '-o', 'use_path_request_style',
                '-o', 'allow_other'
            ]
            
            LOG.info(f"Mounting S3 bucket {bucket} to {mount_path}")
            
            # Start subprocess in its own process group
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                preexec_fn=os.setsid
            )
            
            # Wait for mount to complete
            time.sleep(3)
            
            # Check if process is still running
            if process.poll() is not None:
                stdout, stderr = process.communicate()
                error_msg = f"S3 mount failed: {stderr.decode()}"
                LOG.error(error_msg)
                self._remove_passwd_file(target_id)
                raise MountException(error_msg)
            
            # Verify mount
            if not self.is_mounted(mount_path):
                process.terminate()
                self._remove_passwd_file(target_id)
                raise MountException("S3 mount verification failed")
            
            # Store process reference
            with self.process_lock:
                self.processes[target_id] = process
                self._write_pidfile(target_id, process.pid)
            
            LOG.info(f"S3 mount successful: {mount_path} (PID: {process.pid})")
            return True
            
        except MountException:
            raise
        except Exception as e:
            error_msg = f"S3 mount error: {str(e)}"
            LOG.error(error_msg)
            raise MountException(error_msg)
    
    def unmount(self, target_id: str, mount_path: str) -> bool:
        """Unmount S3 FUSE filesystem"""
        try:
            LOG.info(f"Unmounting S3: {mount_path}")
            
            # Unmount using fusermount
            subprocess.run(
                ['fusermount', '-u', mount_path],
                capture_output=True,
                text=True,
                check=True,
                timeout=30
            )
            
            # Stop the FUSE process
            with self.process_lock:
                process = self.processes.get(target_id)
                if process:
                    try:
                        os.killpg(os.getpgid(process.pid), signal.SIGTERM)
                        process.wait(timeout=5)
                    except Exception as e:
                        LOG.warning(f"Error stopping S3 process: {e}")
                        try:
                            os.killpg(os.getpgid(process.pid), signal.SIGKILL)
                        except:
                            pass
                    
                    del self.processes[target_id]
            
            # Cleanup
            self._remove_pidfile(target_id)
            self._remove_passwd_file(target_id)
            
            # Remove mount point if empty
            if os.path.exists(mount_path) and not os.listdir(mount_path):
                os.rmdir(mount_path)
            
            LOG.info(f"S3 unmount successful: {mount_path}")
            return True
            
        except subprocess.CalledProcessError as e:
            error_msg = f"S3 unmount failed: {e.stderr}"
            LOG.error(error_msg)
            raise UnmountException(error_msg)
        except Exception as e:
            error_msg = f"S3 unmount error: {str(e)}"
            LOG.error(error_msg)
            raise UnmountException(error_msg)
    
    def is_mounted(self, mount_path: str) -> bool:
        """Check if S3 path is mounted"""
        try:
            with open('/proc/mounts', 'r') as f:
                for line in f:
                    parts = line.split()
                    if len(parts) >= 2 and parts[1] == mount_path:
                        return True
            return False
        except Exception as e:
            LOG.error(f"Error checking mount status: {e}")
            return False
    
    def get_mount_info(self, mount_path: str) -> Dict[str, Any]:
        """Get S3 mount information"""
        try:
            with open('/proc/mounts', 'r') as f:
                for line in f:
                    parts = line.split()
                    if len(parts) >= 4 and parts[1] == mount_path:
                        return {
                            'device': parts[0],
                            'mount_point': parts[1],
                            'fs_type': parts[2],
                            'options': parts[3]
                        }
            return {}
        except Exception as e:
            LOG.error(f"Error getting mount info: {e}")
            return {}
    
    def reconcile_on_startup(self):
        """Reconcile S3 mounts on startup"""
        LOG.info("Reconciling S3 mounts on startup...")
        
        try:
            for filename in os.listdir(self.pidfile_dir):
                if filename.endswith('.pid'):
                    target_id = filename[:-4]
                    pid = self._read_pidfile(target_id)
                    
                    if pid and psutil.pid_exists(pid):
                        try:
                            process = psutil.Process(pid)
                            if 's3fs' in ' '.join(process.cmdline()):
                                LOG.info(f"Adopting existing S3 mount for {target_id} (PID: {pid})")
                            else:
                                LOG.warning(f"PID {pid} is not s3fs, removing pidfile")
                                self._remove_pidfile(target_id)
                        except Exception as e:
                            LOG.warning(f"Could not adopt process {pid}: {e}")
                            self._remove_pidfile(target_id)
                    else:
                        LOG.info(f"Stale pidfile for {target_id}, removing")
                        self._remove_pidfile(target_id)
                        
        except Exception as e:
            LOG.error(f"Error during S3 reconciliation: {e}")

