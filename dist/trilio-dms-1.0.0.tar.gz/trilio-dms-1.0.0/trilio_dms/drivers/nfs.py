"""NFS mount driver implementation"""

import os
import subprocess
from typing import Dict, Any

from trilio_dms.drivers.base import BaseMountDriver
from trilio_dms.utils.logger import get_logger
from trilio_dms.utils.exceptions import MountException, UnmountException

LOG = get_logger(__name__)


class NFSDriver(BaseMountDriver):
    """NFS mount driver"""
    
    def mount(self, target_id: str, mount_path: str, **kwargs) -> bool:
        """Mount NFS share"""
        share = kwargs.get('share')
        options = kwargs.get('options', 'defaults')
        
        if not share:
            raise MountException("NFS share not specified")
        
        try:
            # Create mount point
            os.makedirs(mount_path, exist_ok=True)
            
            # Build mount command
            cmd = ['mount', '-t', 'nfs']
            if options:
                cmd.extend(['-o', options])
            cmd.extend([share, mount_path])
            
            LOG.info(f"Mounting NFS: {' '.join(cmd)}")
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                check=True,
                timeout=30
            )
            
            LOG.info(f"NFS mount successful: {mount_path}")
            return True
            
        except subprocess.CalledProcessError as e:
            error_msg = f"NFS mount failed: {e.stderr}"
            LOG.error(error_msg)
            raise MountException(error_msg)
        except subprocess.TimeoutExpired:
            error_msg = "NFS mount timed out"
            LOG.error(error_msg)
            raise MountException(error_msg)
        except Exception as e:
            error_msg = f"NFS mount error: {str(e)}"
            LOG.error(error_msg)
            raise MountException(error_msg)
    
    def unmount(self, target_id: str, mount_path: str) -> bool:
        """Unmount NFS share"""
        try:
            LOG.info(f"Unmounting NFS: {mount_path}")
            
            subprocess.run(
                ['umount', mount_path],
                capture_output=True,
                text=True,
                check=True,
                timeout=30
            )
            
            # Clean up mount point
            if os.path.exists(mount_path) and not os.listdir(mount_path):
                os.rmdir(mount_path)
            
            LOG.info(f"NFS unmount successful: {mount_path}")
            return True
            
        except subprocess.CalledProcessError as e:
            error_msg = f"NFS unmount failed: {e.stderr}"
            LOG.error(error_msg)
            raise UnmountException(error_msg)
        except Exception as e:
            error_msg = f"NFS unmount error: {str(e)}"
            LOG.error(error_msg)
            raise UnmountException(error_msg)
    
    def is_mounted(self, mount_path: str) -> bool:
        """Check if NFS path is mounted"""
        try:
            with open('/proc/mounts', 'r') as f:
                for line in f:
                    parts = line.split()
                    if len(parts) >= 2 and parts[1] == mount_path:
                        return True
            return False
        except Exception as e:
            LOG.error(f"Error checking mount status: {e}")
            return False
    
    def get_mount_info(self, mount_path: str) -> Dict[str, Any]:
        """Get NFS mount information"""
        try:
            with open('/proc/mounts', 'r') as f:
                for line in f:
                    parts = line.split()
                    if len(parts) >= 4 and parts[1] == mount_path:
                        return {
                            'device': parts[0],
                            'mount_point': parts[1],
                            'fs_type': parts[2],
                            'options': parts[3]
                        }
            return {}
        except Exception as e:
            LOG.error(f"Error getting mount info: {e}")
            return {}

